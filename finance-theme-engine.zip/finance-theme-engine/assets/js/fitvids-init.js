/**
 * Initiate FitVids.
 */
jQuery( document ).ready( function($) {
	$( '.site-container' ).fitVids();
});
