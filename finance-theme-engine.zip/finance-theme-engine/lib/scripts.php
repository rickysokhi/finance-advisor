<?php

// Enqueue Javascript files
add_action( 'wp_enqueue_scripts', 'finance_enqueue_scripts' );
function finance_enqueue_scripts() {

	// Use minified files if script debug is not being used.
	$suffix = finance_get_suffix();

	// Enqueue the financen global js file.
	wp_enqueue_script( 'finance-theme-engine', finance_THEME_ENGINE_PLUGIN_URL . "assets/js/finance-theme{$suffix}.js", array( 'jquery' ), finance_THEME_ENGINE_VERSION, true );
	wp_localize_script( 'finance-theme-engine', 'financeVars', array(
		'financenMenu'    => __( 'Menu', 'genesis' ),
		'subMenu'     => __( 'Menu', 'genesis' ),
		'subMenuAria' => __( 'sub-menu toggle', 'genesis' ),
		'search_box'  => sprintf( '<div class="search-box" style="display:none;">%s</div>', get_search_form(false) ),
	) );

	// Maybe enabled responsive videos.
	$responsive_videos = apply_filters( 'finance_enable_responsive_videos', '__return_true' );
	if ( $responsive_videos ) {
		// FitVids.
		wp_enqueue_script( 'finance-responsive-videos', finance_THEME_ENGINE_PLUGIN_URL . "assets/js/fitvids{$suffix}.js", array( 'jquery' ), '1.2.0', true );
		wp_enqueue_script( 'finance-responsive-video-init', finance_THEME_ENGINE_PLUGIN_URL . "assets/js/fitvids-init{$suffix}.js", array( 'finance-responsive-videos' ), finance_THEME_ENGINE_VERSION, true );
	}

	// Register Slick.
	wp_register_script( 'finance-slick', finance_THEME_ENGINE_PLUGIN_URL . "assets/js/slick{$suffix}.js", array( 'jquery' ), '1.8.0', true );
	wp_register_script( 'finance-slick-init', finance_THEME_ENGINE_PLUGIN_URL . "assets/js/slick-init{$suffix}.js", array( 'finance-slick' ), finance_THEME_ENGINE_VERSION, true );
}

// Enqueue CSS files.
add_action( 'wp_enqueue_scripts', 'finance_enqueue_styles' );
function finance_enqueue_styles() {

	// Use minified files if script debug is not being used.
	$suffix = finance_get_suffix();

	wp_enqueue_style( 'finance-theme-engine', finance_THEME_ENGINE_PLUGIN_URL . "assets/css/finance-theme{$suffix}.css", array(), finance_THEME_ENGINE_VERSION );
	wp_enqueue_style( 'flexington', finance_THEME_ENGINE_PLUGIN_URL . "assets/css/flexington{$suffix}.css", array(), '2.3.5' );
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css', array(), finance_THEME_ENGINE_VERSION );
}

// Remove WooCommerce default layout styles.
add_filter( 'woocommerce_enqueue_styles', 'finance_woocommerce_styles' );
function finance_woocommerce_styles( $styles ) {

	$file_name = 'finance-woocommerce';
	$file_path = get_stylesheet_directory() . '/assets/css/' . $file_name . 'css';

	// If the file exists in the child theme /assets/css/{file_name}
	if ( file_exists( $file_path ) ) {
		// Use child theme file.
		$src = get_stylesheet_directory_uri() . '/assets/css/' . $file_name . 'css';
	} else {

		// Use minified files if script debug is not being used.
		$suffix = finance_get_suffix();

		// Use our plugin file
		$src = finance_THEME_ENGINE_PLUGIN_URL . "assets/css/{$file_name}{$suffix}.css";
	}

	$styles['finance-woocommerce'] = array(
		'src'     => $src,
		'deps'    => '',
		'version' => finance_THEME_ENGINE_VERSION,
		'media'   => 'all',
	);

	// Bail if account, cart, or checkout pages. We need layout stuff here.
	if ( is_account_page() || is_cart() || is_checkout() ) {
		return $styles;
	}

	unset( $styles['woocommerce-layout'] );

	return $styles;
}
