<?php

/**
 * Build columns wrap.
 *
 * @access  private
 */
class finance_Columns {

	private $args;

	private $content;

	public function __construct( $args = array(), $content = null ) {

		$this->args    = $args;
		$this->content = $content;

		// Parse defaults and args.
		$this->args = shortcode_atts( array(
			'align'      => '',
			'align_cols' => '',
			'align_text' => '',
			'bottom'     => '',
			'class'      => '',   // HTML classes (space separated)
			'gutter'     => '30', // Space between columns (5, 10, 20, 30, 40, 50) only
			'id'         => '',   // Add HTML id
			'style'      => '',   // Inline styles
		), $this->args, 'columns' );

		// Sanitize args.
		$this->args = array(
			'align'      => finance_sanitize_keys( $this->args['align'] ),
			'align_cols' => finance_sanitize_keys( $this->args['align_cols'] ),
			'align_text' => finance_sanitize_keys( $this->args['align_text'] ),
			'bottom'     => is_numeric( $this->args['bottom'] ) ? absint( $this->args['bottom'] ) : '',
			'class'      => finance_sanitize_html_classes( $this->args['class'] ),
			'gutter'     => absint( $this->args['gutter'] ),
			'id'         => sanitize_html_class( $this->args['id'] ),
			'style'      => sanitize_text_field( $this->args['style'] ),
		);

	}

	/**
	 * Return the columns HTML.
	 *
	 * @return  string|HTML
	 */
	function render() {

		// Bail if no content.
		if ( null === $this->content ) {
			return;
		}

		// Row attributes.
		$attributes = array(
			'class' => finance_add_classes( $this->args['class'], 'columns-shortcode row' ),
			'id'    => ! empty( $this->args['id'] ) ? $this->args['id'] : '',
		);

		// Add gutter.
		$attributes['class'] = finance_add_classes( sprintf( 'gutter-%s', $this->args['gutter'] ), $attributes['class'] );

		// Add row align classes.
		$attributes['class'] = finance_add_row_align_classes( $attributes['class'], $this->args );

		// Add bottom margin classes.
		if ( finance_is_valid_bottom( $this->args['bottom'] ) ) {
			$attributes['class'] = finance_add_classes( finance_get_bottom_class( $this->args['bottom'] ), $attributes['class'] );
		}

		// Maybe add inline styles.
		$attributes = finance_add_inline_styles( $attributes, $this->args['style'] );

		// Only do_shortcode cause finance_get_processed_content() happens inside each col.
		return sprintf( '<div %s>%s</div>', genesis_attr( 'flex-row', $attributes, $this->args ), do_shortcode( $this->content ) );
	}

}
