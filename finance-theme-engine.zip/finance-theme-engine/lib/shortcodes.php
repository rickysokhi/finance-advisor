<?php

// Enable shortcodes in widgets.
add_filter( 'widget_text', 'do_shortcode' );

// Custom Post Type Archive Intro Text.
add_filter( 'genesis_cpt_archive_intro_text_output', 'do_shortcode' );

// Author Archive Intro Text.
add_filter( 'genesis_author_intro_text_output', 'do_shortcode' );

// Term Archive Intro Text.
add_filter( 'genesis_term_intro_text_output', 'do_shortcode' );

// Filter the content.
add_filter( 'the_content', 'finance_content_filter_shortcodes' );

// Register shortcodes.
add_shortcode( 'callout',              'finance_get_callout_shortcode' );
add_shortcode( 'grid',                 'finance_get_grid_shortcode' );
add_shortcode( 'section',              'finance_get_section_shortcode' );
add_shortcode( 'columns',              'finance_get_columns_shortcode' );
add_shortcode( 'col',                  'finance_get_col_shortcode' );
add_shortcode( 'col_auto',             'finance_get_col_auto_shortcode' );
add_shortcode( 'col_one_twelfth',      'finance_get_col_one_twelfth_shortcode' );
add_shortcode( 'col_one_sixth',        'finance_get_col_one_sixth_shortcode' );
add_shortcode( 'col_one_fourth',       'finance_get_col_one_fourth_shortcode' );
add_shortcode( 'col_one_third',        'finance_get_col_one_third_shortcode' );
add_shortcode( 'col_five_twelfths',    'finance_get_col_five_twelfths_shortcode' );
add_shortcode( 'col_one_half',         'finance_get_col_one_half_shortcode' );
add_shortcode( 'col_seven_twelfths',   'finance_get_col_seven_twelfths_shortcode' );
add_shortcode( 'col_two_thirds',       'finance_get_col_two_thirds_shortcode' );
add_shortcode( 'col_three_fourths',    'finance_get_col_three_fourths_shortcode' );
add_shortcode( 'col_five_sixths',      'finance_get_col_five_sixths_shortcode' );
add_shortcode( 'col_eleven_twelfths',  'finance_get_col_eleven_twelfths_shortcode' );
add_shortcode( 'col_one_whole',        'finance_get_col_one_whole_shortcode' );

function finance_get_callout_shortcode( $atts, $content = null ) {
	$callout = new finance_Callout( $atts, $content );
	return $callout->render();
}

function finance_get_grid_shortcode( $atts, $content = null ) {
	$grid = new finance_Grid( $atts, $content );
	return $grid->render();
}

function finance_get_section_shortcode( $atts, $content = null ) {
	$section = new finance_Section( $atts, $content );
	return $section->render();
}

function finance_get_columns_shortcode( $atts, $content = null ) {
	$columns = new finance_Columns( $atts, $content );
	return $columns->render();
}

function finance_get_col_shortcode( $atts, $content = null ) {
	$col = new finance_Col( 'col', $atts, $content );
	return $col->render();
}

function finance_get_col_auto_shortcode( $atts, $content = null ) {
	$col = new finance_Col( 'auto', $atts, $content );
	return $col->render();
}

function finance_get_col_one_twelfth_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '1', $atts, $content );
	return $col->render();
}

function finance_get_col_one_sixth_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '2', $atts, $content );
	return $col->render();
}

function finance_get_col_one_fourth_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '3', $atts, $content );
	return $col->render();
}

function finance_get_col_one_third_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '4', $atts, $content );
	return $col->render();
}

function finance_get_col_five_twelfths_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '5', $atts, $content );
	return $col->render();
}

function finance_get_col_one_half_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '6', $atts, $content );
	return $col->render();
}

function finance_get_col_seven_twelfths_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '7', $atts, $content );
	return $col->render();
}

function finance_get_col_two_thirds_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '8', $atts, $content );
	return $col->render();
}

function finance_get_col_three_fourths_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '9', $atts, $content );
	return $col->render();
}

function finance_get_col_five_sixths_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '10', $atts, $content );
	return $col->render();
}

function finance_get_col_eleven_twelfths_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '11', $atts, $content );
	return $col->render();
}

function finance_get_col_one_whole_shortcode( $atts, $content = null ) {
	$col = new finance_Col( '12', $atts, $content );
	return $col->render();
}
