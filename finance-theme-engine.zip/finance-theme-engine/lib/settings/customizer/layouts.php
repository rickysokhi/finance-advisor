<?php

/**
 * Register new Customizer elements.
 *
 * @access  private
 *
 * @param   WP_Customize_Manager $wp_customize WP_Customize_Manager instance.
 */
add_action( 'customize_register', 'finance_register_customizer_site_layout_settings', 20 );
function finance_register_customizer_site_layout_settings( $wp_customize ) {

	/* **************** *
	 * finance Site Layouts *
	 * **************** */

	// Remove Genesis "Content Archives" section.
	$wp_customize->remove_section( 'genesis_layout' );

	$section        = 'finance_site_layout';
	$settings_field = 'genesis-settings';
	$post_type      = 'post';

	// Section.
	$wp_customize->add_section(
		$section,
		array(
			'title'    => __( 'finance Site Layout', 'finance-theme-engine' ),
			'priority' => '40',
		)
	);

	// Default Layout.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'site_layout' ),
		array(
			'default'           => sanitize_key( genesis_get_default_layout() ),
			'type'              => 'option',
			'sanitize_callback' => 'sanitize_key',
		)
	);
	$wp_customize->add_control(
		'site_layout',
		array(
			'label'    => __( 'Default Layout', 'finance-theme-engine' ),
			'section'  => $section,
			'settings' => _finance_customizer_get_field_name( $settings_field, 'site_layout' ),
			'priority' => 10,
			'type'     => 'select',
			'choices'  => genesis_get_layouts_for_customizer(),
		)
	);

	// Archive Layout.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'layout_archive' ),
		array(
			'default'           => sanitize_key( finance_get_default_option( 'layout_archive' ) ),
			'type'              => 'option',
			'sanitize_callback' => 'sanitize_key',
		)
	);
	$wp_customize->add_control(
		'layout_archive',
		array(
			'label'    => __( 'Archives', 'finance-theme-engine' ),
			'section'  => $section,
			'settings' => _finance_customizer_get_field_name( $settings_field, 'layout_archive' ),
			'priority' => 10,
			'type'     => 'select',
			'choices'  => array_merge( array( '' => __( '- Site Default -', 'finance-theme-engine' ) ), genesis_get_layouts_for_customizer() ),
		)
	);

	// Pages.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'layout_page' ),
		array(
			'default'           => sanitize_key( finance_get_default_option( 'layout_page' ) ),
			'type'              => 'option',
			'sanitize_callback' => 'sanitize_key',
		)
	);
	$wp_customize->add_control(
		'layout_page',
		array(
			'label'    => __( 'Pages', 'finance-theme-engine' ),
			'section'  => $section,
			'settings' => _finance_customizer_get_field_name( $settings_field, 'layout_page' ),
			'priority' => 10,
			'type'     => 'select',
			'choices'  => array_merge( array( '' => __( '- Site Default -', 'finance-theme-engine' ) ), genesis_get_layouts_for_customizer() ),
		)
	);

	// Posts.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'layout_post' ),
		array(
			'default'           => sanitize_key( finance_get_default_option( 'layout_post' ) ),
			'type'              => 'option',
			'sanitize_callback' => 'sanitize_key',
		)
	);
	$wp_customize->add_control(
		'layout_post',
		array(
			'label'    => __( 'Posts', 'finance-theme-engine' ),
			'section'  => $section,
			'settings' => _finance_customizer_get_field_name( $settings_field, 'layout_post' ),
			'priority' => 10,
			'type'     => 'select',
			'choices'  => array_merge( array( '' => __( '- Site Default -', 'finance-theme-engine' ) ), genesis_get_layouts_for_customizer() ),
		)
	);

	// Boxed Containers.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'boxed_elements' ),
		array(
			'default'           => _finance_customizer_multicheck_sanitize_key( finance_get_default_option( 'boxed_elements' ) ),
			'type'              => 'option',
			'sanitize_callback' => '_finance_customizer_multicheck_sanitize_key',
		)
	);
	$wp_customize->add_control(
		new finance_Customize_Control_Multicheck( $wp_customize,
			'boxed_elements',
			array(
				'label'       => __( 'Boxed Containers', 'finance-theme-engine' ),
				'description' => __( 'Display the following elements with a boxed look:', 'finance-theme-engine' ),
				'section'     => $section,
				'settings'    => _finance_customizer_get_field_name( $settings_field, 'boxed_elements' ),
				'priority'    => 10,
				'choices'     => array(
					'site_container'       => __( 'Site Container (fixed width)', 'finance-theme-engine' ),
					'content_sidebar_wrap' => __( 'Content Sidebar Wrap', 'finance-theme-engine' ),
					'content'              => __( 'financen Content', 'finance-theme-engine' ),
					'entry_singular'       => __( 'Single Posts/Entries', 'finance-theme-engine' ),
					'entry_archive'        => __( 'Archive Posts/Entries', 'finance-theme-engine' ),
					'sidebar'              => __( 'Primary Sidebar', 'finance-theme-engine' ),
					'sidebar_alt'          => __( 'Secondary Sidebar', 'finance-theme-engine' ),
					'sidebar_widgets'      => __( 'Primary Sidebar Widgets', 'finance-theme-engine' ),
					'sidebar_alt_widgets'  => __( 'Secondary Sidebar Widget', 'finance-theme-engine' ),
					'author_box'           => __( 'After Entry Author Box', 'finance-theme-engine' ),
					'after_entry_widgets'  => __( 'After Entry Widgets', 'finance-theme-engine' ),
					'adjacent_entry_nav'   => __( 'Previous/Next Entry Navigation', 'finance-theme-engine' ),
					'comment_wrap'         => __( 'Comments Wrap', 'finance-theme-engine' ),
					'comment'              => __( 'Comments', 'finance-theme-engine' ),
					'comment_respond'      => __( 'Comment Submission Form', 'finance-theme-engine' ),
					'pings'                => __( 'Pings and Trackbacks', 'finance-theme-engine' ),
				),
			)
		)
	);

}
