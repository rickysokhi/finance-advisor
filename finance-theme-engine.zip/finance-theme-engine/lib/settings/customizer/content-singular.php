<?php

/**
 * Register new Customizer elements.
 *
 * @access  private
 *
 * @param   WP_Customize_Manager $wp_customize WP_Customize_Manager instance.
 */
add_action( 'customize_register', 'finance_register_customizer_content_singular_settings', 20 );
function finance_register_customizer_content_singular_settings( $wp_customize ) {

	/* ************ *
	 * finance Settings *
	 * ************ */

	$section        = 'finance_content_singular';
	$panel          = 'finance_content_types';
	$settings_field = 'genesis-settings';
	$post_type      = 'post';

	// Section.
	$wp_customize->add_section(
		$section,
		array(
			'title'    => __( 'Single Entries Default', 'finance-theme-engine' ),
			'priority' => '38',
			'panel'    => $panel,
		)
	);

	// Featured Image - heading only.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'singular_featured_image_heading' ),
		array(
			'default' => '',
			'type'    => 'option',
		)
	);
	$wp_customize->add_control(
		new finance_Customize_Control_Content( $wp_customize,
			'singular_featured_image_heading',
			array(
				'label'    => __( 'Featured Image', 'finance-theme-engine' ),
				'section'  => $section,
				'settings' => false,
			)
		)
	);

	// Featured image - Pages.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'singular_image_page' ),
		array(
			'default'           => finance_sanitize_one_zero( finance_get_default_option( 'singular_image_page' ) ),
			'type'              => 'option',
			'sanitize_callback' => 'finance_sanitize_one_zero',
		)
	);
	$wp_customize->add_control(
		'singular_image_page',
		array(
			'label'    => __( 'Display the featured image on pages', 'finance-theme-engine' ),
			'section'  => $section,
			'settings' => _finance_customizer_get_field_name( $settings_field, 'singular_image_page' ),
			'type'     => 'checkbox',
		)
	);

	// Featured image - Posts.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'singular_image_post' ),
		array(
			'default'           => finance_sanitize_one_zero( finance_get_default_option( 'singular_image_post' ) ),
			'type'              => 'option',
			'sanitize_callback' => 'finance_sanitize_one_zero',
		)
	);
	$wp_customize->add_control(
		'singular_image_post',
		array(
			'label'    => __( 'Display the featured image on posts', 'finance-theme-engine' ),
			'section'  => $section,
			'settings' => _finance_customizer_get_field_name( $settings_field, 'singular_image_post' ),
			'type'     => 'checkbox',
		)
	);

	// Entry Meta.
	if ( post_type_supports( $post_type, 'genesis-entry-meta-before-content' ) || post_type_supports( $post_type, 'genesis-entry-meta-after-content' ) ) {

		$remove_meta_choices = array();

		if ( post_type_supports( $post_type, 'genesis-entry-meta-before-content' ) ) {
			$remove_meta_choices['post_info'] = __( 'Remove Post Info', 'finance-theme-engine' );
		}

		if ( post_type_supports( $post_type, 'genesis-entry-meta-after-content' ) ) {
			$remove_meta_choices['post_meta'] = __( 'Remove Post Meta', 'finance-theme-engine' );
		}

		$wp_customize->add_setting(
			_finance_customizer_get_field_name( $settings_field, 'remove_meta_post' ),
			array(
				'default'           => _finance_customizer_multicheck_sanitize_key( finance_get_default_option( 'remove_meta_post' ) ),
				'type'              => 'option',
				'sanitize_callback' => '_finance_customizer_multicheck_sanitize_key',
			)
		);
		$wp_customize->add_control(
			new finance_Customize_Control_Multicheck( $wp_customize,
				'remove_meta_post',
				array(
					'label'    => __( 'Post Entry Meta', 'finance-theme-engine' ),
					'section'  => $section,
					'settings' => _finance_customizer_get_field_name( $settings_field, 'remove_meta_post' ),
					'priority' => 10,
					'choices'  => $remove_meta_choices,
				)
			)
		);

	}

}
