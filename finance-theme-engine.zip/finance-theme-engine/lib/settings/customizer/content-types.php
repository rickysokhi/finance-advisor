<?php

/**
 * Register new Customizer elements.
 * Register priorty 10 since our actual settings are registered at 20.
 *
 * @access  private
 *
 * @param   WP_Customize_Manager $wp_customize WP_Customize_Manager instance.
 */
add_action( 'customize_register', 'finance_register_customizer_content_types_section', 10 );
function finance_register_customizer_content_types_section( $wp_customize ) {

	/* ***************** *
	 * finance Content Types *
	 * ***************** */

	// Panel.
	$wp_customize->add_panel( 'finance_content_types', array(
		'priority' => 37,
		'title'    => __( 'finance Content Types', 'finance-theme-engine' ),
	) );

}
