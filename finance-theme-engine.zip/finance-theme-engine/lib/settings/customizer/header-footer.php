<?php

/**
 * Register new Customizer elements.
 *
 * @access  private
 *
 * @param   WP_Customize_Manager $wp_customize WP_Customize_Manager instance.
 */
add_action( 'customize_register', 'finance_register_customizer_header_footer_settings', 20 );
function finance_register_customizer_header_footer_settings( $wp_customize ) {

	/* ************ *
	 * finance Settings *
	 * ************ */

	$section        = 'finance_header_footer';
	$settings_field = 'genesis-settings';

	// Section.
	$wp_customize->add_section(
		$section,
		array(
			'title'    => __( 'finance Header & Footer', 'finance-theme-engine' ),
			'priority' => '35',
		)
	);

	// Header heading.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'header_customizer_heading' ),
		array(
			'default' => '',
			'type'    => 'option',
		)
	);
	$wp_customize->add_control(
		new finance_Customize_Control_Content( $wp_customize,
			'header_customizer_heading',
			array(
				'label'       => __( 'Header', 'finance-theme-engine' ),
				'description' => __( 'These settings are disabled on mobile.', 'finance-theme-engine' ),
				'section'     => $section,
				'settings'    => false,
			)
		)
	);

	// Sticky Header.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'enable_sticky_header' ),
		array(
			'default'           => 0,
			'type'              => 'option',
			'sanitize_callback' => 'finance_sanitize_one_zero',
		)
	);
	$wp_customize->add_control(
		'enable_sticky_header',
		array(
			'label'    => __( 'Enable sticky header', 'finance-theme-engine' ),
			'section'  => $section,
			'settings' => _finance_customizer_get_field_name( $settings_field, 'enable_sticky_header' ),
			'type'     => 'checkbox',
		)
	);

	// Shrink Header.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'enable_shrink_header' ),
		array(
			'default'           => 0,
			'type'              => 'option',
			'sanitize_callback' => 'finance_sanitize_one_zero',
		)
	);
	$wp_customize->add_control(
		'enable_shrink_header',
		array(
			'label'    => __( 'Enable shrink header', 'finance-theme-engine' ),
			'section'  => $section,
			'settings' => _finance_customizer_get_field_name( $settings_field, 'enable_shrink_header' ),
			'type'     => 'checkbox',
		)
	);

	// Footer widgets.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'footer_widget_count' ),
		array(
			'default'           => 2,
			'type'              => 'option',
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'footer_widget_count',
		array(
			'label'       => __( 'Footer widget areas', 'finance-theme-engine' ),
			'description' => __( 'Save and reload customizer to view changes.', 'finance-theme-engine' ),
			'section'     => $section,
			'settings'    => _finance_customizer_get_field_name( $settings_field, 'footer_widget_count' ),
			'priority'    => 10,
			'type'        => 'select',
			'choices'     => array(
				0 => __( 'None', 'finance-theme-engine' ),
				1 => __( '1', 'finance-theme-engine' ),
				2 => __( '2', 'finance-theme-engine' ),
				3 => __( '3', 'finance-theme-engine' ),
				4 => __( '4', 'finance-theme-engine' ),
				6 => __( '6', 'finance-theme-engine' ),
			),
		)
	);

	// Mobile menu.
	$wp_customize->add_setting(
		_finance_customizer_get_field_name( $settings_field, 'mobile_menu_style' ),
		array(
			'default'           => 'standard',
			'type'              => 'option',
			'sanitize_callback' => 'sanitize_key',
		)
	);
	$wp_customize->add_control(
		'mobile_menu_style',
		array(
			'label'    => __( 'Mobile menu style', 'finance-theme-engine' ),
			'section'  => $section,
			'settings' => _finance_customizer_get_field_name( $settings_field, 'mobile_menu_style' ),
			'priority' => 10,
			'type'     => 'select',
			'choices'  => array(
				'standard' => __( 'Standard Menu', 'finance-theme-engine' ),
				'side'     => __( 'Side Menu', 'finance-theme-engine' ),
			),
		)
	);

}
