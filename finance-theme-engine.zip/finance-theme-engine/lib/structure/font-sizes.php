<?php

/**
 * Add text size class to the body.
 *
 * @param   array  $classes  The body classes.
 *
 * @return  array  The modified classes.
 */
add_filter( 'body_class', 'finance_body_text_size' );
function finance_body_text_size( $classes ) {
	$classes[] = 'text-md';
	return $classes;
}

/**
 * Add text size class to the footer widgets.
 *
 * @param   array  $attributes  The element attributes.
 *
 * @return  array  The modified attributes.
 */
// add_filter( 'genesis_attr_footer-widgets', 'finance_footer_widgets_text_size' );
function finance_footer_widgets_text_size( $attributes ) {
	$attributes['class'] .= ' text-sm';
	return $attributes;
}

/**
 * Add text size class to the site footer.
 *
 * @param   array  $attributes  The element attributes.
 *
 * @return  array  The modified attributes.
 */
add_filter( 'genesis_attr_site-footer', 'finance_site_footer_text_size' );
function finance_site_footer_text_size( $attributes ) {
	$attributes['class'] .= ' text-sm';
	return $attributes;
}
